//********************************************************************************
//Universidad del Valle de Guatemala
//IE2023: Programacion de Microcontroladores
//Autor: Fernando Gabriel Caballeros Cu
//Proyecto: Laboratorio 05
//Archivo: main.c
//Hardware: ATMega328p
//Created: 15/04/2023
//********************************************************************************

#define F_CPU 16000000
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "PWM0/PWM0.h"
#include "PWM1/PWM1.h"
#include "ADC/ADC.h"
#include "Timer0/Timer0.h"
#include "TIMER2/TIMER2.h"
volatile uint8_t valorADC = 0;
volatile uint8_t valorADC_l = 0;
volatile uint8_t valorADC_S = 0;
volatile float valor_reescalado=0;
volatile uint8_t PuertoADC=4;
volatile uint8_t PuertoADC_=5;
volatile uint16_t destino=0;

void init_pines(void){

	DDRC &= ~(1 << DDC4) & ~(1 << DDC5) & ~(1 << DDC6);
	PORTC |= (1 << PORTC4) | (1 << PORTC5)| (1 << PORTC6);
	DDRD |= (1 << DDD7);
	sei();

}

uint16_t reescalar(uint8_t valor_, uint8_t max_origen, uint16_t max_destino) {
	float valor_normalizado = (float)valor_ / max_origen;
	uint16_t valor_reescalado = valor_normalizado * max_destino;

	return valor_reescalado;
}


ISR(TIMER0_COMPA_vect) {
	TIFR0 |= (1 << OCF0A);
}

ISR(TIMER2_COMPA_vect){
	valorADC_l=readADC(6);
	CTC_Timer0A(valorADC_l);
	TIFR2 |= (1 << TOIE2);
}

//frecuencia del adc - 125kHz
int main() {
	init_pines();
	init_ADC(0,0,128);
	
	
	destino=37;
	int preescaler=1024;
	
	init_PWM1A(0,6,preescaler,destino);
	init_PWM1B(0);
	uint8_t valor_1 = 0;
	//PWM 
	//Timer0 duty cycle
	init_Timer0(1,1024);
	
	//timer2 periodo
	init_Timer2(1,1024);
	CTC_Timer2A(255);

	while (1) {
		if (PuertoADC==4)
		{
			valor_1 = readADC(4);
			uint16_t valor_reescalado = reescalar(valor_1, 255, destino);
			duty_cycle1A(valor_reescalado);
			PuertoADC++;
		} else if (PuertoADC==3)
		{
			valor_1 =readADC(3);
			uint16_t valor_reescalado = reescalar(valor_1, 255, destino);
			duty_cycle1B(valor_reescalado);
			PuertoADC=4;
			} else{
			PuertoADC=4;
		}
		if (TCNT2 < OCR0A) {
			PORTD |= (1 << DDD7); // Alto
			} else {
			PORTD &= ~(1 << DDD7); // Bajo
		}
	}

	return 0;
}