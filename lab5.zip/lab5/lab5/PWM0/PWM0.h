/*
 * PWM0.h
 *
 * Created: 15/04/2024 08:45:56
 *  Author: Usuario Dell
 */ 

#ifndef PWM0_H_
#define PWM0_H_
#include <stdint.h>
#include <avr/io.h>

void init_PWM0A(int orientacion,int modo,int preescaler);
void init_PWM0B(int orientacion);
void duty_cycleA(int duty);
void duty_cycleB(int duty);

#endif /* PWM0_H_ */