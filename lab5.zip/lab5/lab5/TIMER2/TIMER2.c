/*
 * TIMER2.c
 *
 * Created: 19/04/2024 16:28:52
 *  Author: Usuario Dell
 */ 

#include "TIMER2.h"

void init_Timer2(int modo, int preescaler){
	TCCR2A=0;
	TCCR2B=0;
	TIMSK2=0;
	if (modo==0){
		//interrupcion por overflow
		TIMSK2 |= (1<<TOIE2);
	}
	if (modo==1){
		TCCR2A |= (1<<WGM21);//MODO CTC
		//interrupcion por comparaci�n
		TIMSK2 |= (1<<OCIE2A)|(1<<OCIE2B);
	}
	
	//preescaler
	switch(preescaler){
		case 1:
		TCCR2B |= (1<<CS20);
		break;
		case 8:
		TCCR2B |= (1<<CS21);
		break;
		case 64:
		TCCR2B |= (1<<CS22);
		break;
		case 256:
		TCCR2B |= (1<<CS22)|(1<<CS21);
		break;
		case 1024:
		TCCR2B |= (1<<CS22)|(1<<CS20)|(1<<CS21);
		break;
	}
}

void CTC_Timer2A(uint8_t valor){
	OCR2A = valor;
}